package com.example.ex;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExApplicationTests {

	@Test
	void contextLoads() {
	}

}
