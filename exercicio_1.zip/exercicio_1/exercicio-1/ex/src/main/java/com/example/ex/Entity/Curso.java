package com.example.ex.Entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;

import java.util.List;

@Entity
public class Curso {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)


    private Long idCurso;

    private String nome;

    private String numeroSala;

    @OneToOne
    @JoinColumn(name = "idProfessor", referencedColumnName = "idProfessor")


    @OneToMany(mappedBy = "curso", cascade = CascadeType.ALL)
    private Professor professor;
    @JsonBackReference
    private List<Aluno> alunos;

    public Curso() {
    }

    public Curso(Long idCurso, String nome, String numeroSala) {
        this.idCurso = idCurso;
        this.nome = nome;
        this.numeroSala = numeroSala;
    }

    public Long getIdCurso() {
        return idCurso;
    }

    public void setIdCurso(Long idCurso) {
        this.idCurso = idCurso;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getNumeroSala() {
        return numeroSala;
    }

    public void setNumeroSala(String numeroSala) {
        this.numeroSala = numeroSala;
    }

}